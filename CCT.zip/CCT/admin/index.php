<?php 

include('header.php');
// echo '<pre>';
// print_r($origins);
// echo '</pre>';
 ?>




<div  class="container-fluid" style="margin-top;80px">
	<?php include('menubar.php')?>
	<div class="col-md-1"></div>
</div>

<div class="container-fluid">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<div class="panel panel-inverse">
			<div class="panel-body">
			 <h2>
			 CCT POLICE SERVICE
			 </h2>
				
			</div>
		</div>
	</div>
	<div class="col-md-2"></div>
</div>

<?php include('scripts.php'); ?>

</body>
</html>