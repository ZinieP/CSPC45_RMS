<?php  
$dbcon = mysqli_connect ("localhost", "root", "", "cctproj");
mysqli_set_charset($dbcon, 'utf8'); 

?>